const express = require('express');
const db = require('../db');
const { requireRole, requireAuth } = require('../middleware/auth');

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// POST /api/pledges — public. If the visitor is logged in, their pledge is
// linked to their account so it shows up in "My giving".
router.post('/', (req, res) => {
  const { name, email, amount, message } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ error: 'Please enter your name.' });
  if (!email || !EMAIL_RE.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (!amount) return res.status(400).json({ error: 'Please select an amount.' });

  const userId = (req.session && req.session.userId) || null;

  const info = db.prepare(`
    INSERT INTO pledges (user_id, name, email, amount, message) VALUES (?, ?, ?, ?, ?)
  `).run(userId, name.trim(), email.trim().toLowerCase(), String(amount), message || null);

  const pledge = db.prepare('SELECT * FROM pledges WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ pledge });
});

// GET /api/pledges/mine — logged-in member's own giving history
router.get('/mine', requireAuth, (req, res) => {
  const pledges = db.prepare('SELECT * FROM pledges WHERE user_id = ? ORDER BY created_at DESC').all(req.session.userId);
  res.json({ pledges });
});

// GET /api/pledges — admin only, full list
router.get('/', requireRole('admin'), (req, res) => {
  const pledges = db.prepare('SELECT * FROM pledges ORDER BY created_at DESC').all();
  res.json({ pledges });
});

module.exports = router;
