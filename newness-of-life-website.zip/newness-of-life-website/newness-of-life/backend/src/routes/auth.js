const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function publicUser(row) {
  if (!row) return null;
  return { id: row.id, name: row.name, email: row.email, role: row.role, created_at: row.created_at };
}

// POST /api/auth/register — always creates a "member" account.
// Admin accounts are created only via the seed script, never through this
// public endpoint, so nobody can grant themselves admin access.
router.post('/register', (req, res) => {
  const { name, email, password } = req.body || {};

  if (!name || !name.trim()) return res.status(400).json({ error: 'Please enter your name.' });
  if (!email || !EMAIL_RE.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (!password || password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });

  const normalizedEmail = email.trim().toLowerCase();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (existing) return res.status(409).json({ error: 'An account with that email already exists.' });

  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare(`
    INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'member')
  `).run(name.trim(), normalizedEmail, hash);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);

  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: 'Could not start a session.' });
    req.session.userId = user.id;
    req.session.role = user.role;
    res.status(201).json({ user: publicUser(user) });
  });
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Please enter your email and password.' });

  const normalizedEmail = email.trim().toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail);

  // Compare against a dummy hash even when the user doesn't exist, so
  // response timing doesn't reveal whether an email is registered.
  const hashToCheck = user ? user.password_hash : '$2a$12$abcdefghijklmnopqrstuuC8b8b8b8b8b8b8b8b8b8b8b8b8b8b8b8';
  const ok = bcrypt.compareSync(password, hashToCheck);

  if (!user || !ok) return res.status(401).json({ error: 'Incorrect email or password.' });

  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: 'Could not start a session.' });
    req.session.userId = user.id;
    req.session.role = user.role;
    res.json({ user: publicUser(user) });
  });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('nol.sid');
    res.json({ ok: true });
  });
});

// GET /api/auth/me — used by the frontend on every page to know who's logged in
router.get('/me', (req, res) => {
  if (!req.session || !req.session.userId) return res.json({ user: null });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.json({ user: null });
  res.json({ user: publicUser(user) });
});

module.exports = router;
