const express = require('express');
const db = require('../db');
const { requireRole } = require('../middleware/auth');

const router = express.Router();

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// GET /api/events — public
router.get('/', (req, res) => {
  const events = db.prepare('SELECT * FROM events ORDER BY event_date ASC').all();
  res.json({ events });
});

// POST /api/events — admin only
router.post('/', requireRole('admin'), (req, res) => {
  const { title, event_date, event_time, description } = req.body || {};
  if (!title || !title.trim()) return res.status(400).json({ error: 'Title is required.' });
  if (!event_date || !DATE_RE.test(event_date)) return res.status(400).json({ error: 'A valid date (YYYY-MM-DD) is required.' });

  const info = db.prepare(`
    INSERT INTO events (title, event_date, event_time, description) VALUES (?, ?, ?, ?)
  `).run(title.trim(), event_date, event_time || null, description || null);

  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ event });
});

// PUT /api/events/:id — admin only
router.put('/:id', requireRole('admin'), (req, res) => {
  const existing = db.prepare('SELECT * FROM events WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Event not found.' });

  const { title, event_date, event_time, description } = req.body || {};
  if (event_date && !DATE_RE.test(event_date)) return res.status(400).json({ error: 'A valid date (YYYY-MM-DD) is required.' });

  db.prepare(`
    UPDATE events SET title = ?, event_date = ?, event_time = ?, description = ? WHERE id = ?
  `).run(
    (title ?? existing.title).trim(),
    event_date ?? existing.event_date,
    event_time ?? existing.event_time,
    description ?? existing.description,
    req.params.id
  );

  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(req.params.id);
  res.json({ event });
});

// DELETE /api/events/:id — admin only
router.delete('/:id', requireRole('admin'), (req, res) => {
  const result = db.prepare('DELETE FROM events WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: 'Event not found.' });
  res.json({ ok: true });
});

module.exports = router;
