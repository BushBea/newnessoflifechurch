const express = require('express');
const db = require('../db');
const { requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/sermons — public
router.get('/', (req, res) => {
  const sermons = db.prepare('SELECT * FROM sermons ORDER BY created_at DESC').all();
  res.json({ sermons });
});

// POST /api/sermons — admin only
router.post('/', requireRole('admin'), (req, res) => {
  const { title, speaker, duration, video_url, thumbnail, description } = req.body || {};
  if (!title || !title.trim()) return res.status(400).json({ error: 'Title is required.' });
  if (!speaker || !speaker.trim()) return res.status(400).json({ error: 'Speaker is required.' });

  const info = db.prepare(`
    INSERT INTO sermons (title, speaker, duration, video_url, thumbnail, description)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(title.trim(), speaker.trim(), duration || null, video_url || null, thumbnail || null, description || null);

  const sermon = db.prepare('SELECT * FROM sermons WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ sermon });
});

// PUT /api/sermons/:id — admin only
router.put('/:id', requireRole('admin'), (req, res) => {
  const existing = db.prepare('SELECT * FROM sermons WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Sermon not found.' });

  const { title, speaker, duration, video_url, thumbnail, description } = req.body || {};
  db.prepare(`
    UPDATE sermons SET title = ?, speaker = ?, duration = ?, video_url = ?, thumbnail = ?, description = ?
    WHERE id = ?
  `).run(
    (title ?? existing.title).trim(),
    (speaker ?? existing.speaker).trim(),
    duration ?? existing.duration,
    video_url ?? existing.video_url,
    thumbnail ?? existing.thumbnail,
    description ?? existing.description,
    req.params.id
  );

  const sermon = db.prepare('SELECT * FROM sermons WHERE id = ?').get(req.params.id);
  res.json({ sermon });
});

// DELETE /api/sermons/:id — admin only
router.delete('/:id', requireRole('admin'), (req, res) => {
  const result = db.prepare('DELETE FROM sermons WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: 'Sermon not found.' });
  res.json({ ok: true });
});

module.exports = router;
