require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./index');

function seedAdmin() {
  const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD) {
    console.log('Skipping admin seed: set ADMIN_EMAIL and ADMIN_PASSWORD in .env first.');
    return;
  }
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(ADMIN_EMAIL.toLowerCase());
  if (existing) {
    console.log(`Admin account already exists for ${ADMIN_EMAIL}.`);
    return;
  }
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
  db.prepare(`
    INSERT INTO users (name, email, password_hash, role)
    VALUES (?, ?, ?, 'admin')
  `).run(ADMIN_NAME || 'Church Admin', ADMIN_EMAIL.toLowerCase(), hash);
  console.log(`Created admin account for ${ADMIN_EMAIL}. Log in at /login.html on the frontend.`);
}

function seedSampleContent() {
  const sermonCount = db.prepare('SELECT COUNT(*) AS n FROM sermons').get().n;
  if (sermonCount === 0) {
    const insert = db.prepare(`
      INSERT INTO sermons (title, speaker, duration, video_url, thumbnail, description)
      VALUES (@title, @speaker, @duration, @video_url, @thumbnail, @description)
    `);
    const sample = [
      { title: 'Living with Faith', speaker: 'Pastor Nkosinathi Rhulani', duration: '28m', video_url: 'https://www.youtube.com/@nkosinathirhulani195', thumbnail: 'images/image1.jpg', description: 'Practical steps to walk out your faith day to day.' },
      { title: 'Grace and Forgiveness', speaker: 'Pastor Nkosinathi Rhulani', duration: '31m', video_url: 'https://www.youtube.com/@nkosinathirhulani195', thumbnail: 'images/image2.jpg', description: 'Understanding grace and extending forgiveness to others.' },
      { title: 'Walking in Hope', speaker: 'Pastor Nkosinathi Rhulani', duration: '26m', video_url: 'https://www.youtube.com/@nkosinathirhulani195', thumbnail: 'images/image4.jpg', description: 'Finding hope in every season of life.' },
    ];
    sample.forEach(s => insert.run(s));
    console.log(`Seeded ${sample.length} sample sermons.`);
  }

  const eventCount = db.prepare('SELECT COUNT(*) AS n FROM events').get().n;
  if (eventCount === 0) {
    const insert = db.prepare(`
      INSERT INTO events (title, event_date, event_time, description)
      VALUES (@title, @event_date, @event_time, @description)
    `);
    const sample = [
      { title: 'Community Night', event_date: '2026-09-25', event_time: '6:30 PM', description: 'Join us for worship, fellowship, and dinner.' },
      { title: 'Youth Camp', event_date: '2026-10-02', event_time: 'All day', description: 'A fun-filled weekend for teens to grow in faith.' },
      { title: 'Weekly Bible Study', event_date: '2026-09-16', event_time: '7:00 PM', description: 'Dive deeper into Scripture with our small groups.' },
    ];
    sample.forEach(e => insert.run(e));
    console.log(`Seeded ${sample.length} sample events.`);
  }
}

seedAdmin();
seedSampleContent();
console.log('Seeding complete.');
