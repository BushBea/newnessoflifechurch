# Newness of Life Church — Website & Backend

This project has two parts:

- **`frontend/`** — the public website (plain HTML/CSS/JS, no build step). Home, About,
  Sermons, Events, Give, Login, Register, a member Account dashboard, and an Admin dashboard.
- **`backend/`** — a Node.js + Express API that adds real accounts, login sessions, and
  content management (sermons/events/pledges) backed by SQLite.

The frontend works on its own with placeholder content even if the backend isn't running —
but logging in, submitting a pledge, and the admin dashboard all need the backend.

---

## 1. Run the backend

Requirements: Node.js 18+ and npm.

```bash
cd backend
cp .env.example .env      # then edit .env — see "Configuring .env" below
npm install
npm run seed              # creates your admin account + a few sample sermons/events
npm start                 # starts the API on http://localhost:4000
```

### Configuring `.env`

Open `backend/.env` and set:

- `SESSION_SECRET` — a long random string. Generate one with:
  `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — the login for the one admin account `npm run seed` creates.
  Change the password to something strong before you seed a real deployment.
- `CORS_ORIGIN` — the exact URL(s) the frontend is served from (comma-separated). The API
  only accepts cookie-authenticated requests from these origins.

Re-running `npm run seed` is safe — it skips creating the admin account if one already exists,
and only adds sample sermons/events if the tables are empty.

## 2. Run the frontend

The frontend is static files, so any static server works. Two easy options:

**Option A — VS Code Live Server extension:** right-click `frontend/index.html` → "Open with
Live Server". Note the port it uses (e.g. `5500`) and make sure it's listed in `CORS_ORIGIN`.

**Option B — Python's built-in server:**
```bash
cd frontend
python3 -m http.server 5500
```
Then visit `http://localhost:5500`.

By default, `frontend/js/api.js` calls the API at `/api` on the same origin. If your frontend
and backend run on **different ports** (as in local development above), add this one line to
the `<head>` of each HTML page, before `js/api.js` is loaded, pointing at your backend:

```html
<script>window.API_BASE = 'http://localhost:4000/api';</script>
```

(If you deploy the backend to serve the frontend too — see the commented-out line near the
bottom of `backend/server.js` — you don't need this, since everything is then same-origin.)

## 3. Log in

- Go to `login.html` and sign in with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` you seeded — this
  takes you to the **Admin dashboard**, where you can add/edit/delete sermons and events, and
  see everyone who has submitted a pledge or created an account.
- Anyone can create a normal account from `register.html` — this is a **member** account,
  which gets its own dashboard (`account.html`) showing their giving history. There is no
  public way to create an admin account — that's intentional; only `npm run seed` does that.

---

## What was fixed from the original files

The original site (in the uploaded zip) was static HTML with several bugs and no backend:
- a broken logo path (`<img src="Logo">`, missing file extension) and placeholder logo/images
  from `via.placeholder.com` / `picsum.photos` — replaced with the real logo and your own
  compressed photos throughout;
- a malformed WhatsApp link (`href="https://wa.me/0647285173" "` with a stray quote) and a
  doubled-up Facebook URL (`https://https://...`) — both fixed;
- five pages that each duplicated ~150 lines of near-identical CSS and header/footer markup,
  with inconsistent colors between pages — replaced with one shared stylesheet and one shared
  header/footer component (`frontend/js/components.js`) so there's a single source of truth;
- an all-black background with a single neon-blue accent and no real visual identity —
  redesigned around the palette already in your own logo (navy, sage green, gold, teal);
- sermons and events hardcoded directly into the HTML, meaning updating them meant editing
  code — they now load from the backend API, with the old hardcoded content kept only as an
  offline fallback if the API isn't reachable;
- no way to log in, no accounts, and no way to manage content without editing files directly —
  addressed by everything described above.

## Security notes before you go live

- **Change every default.** `SESSION_SECRET` and `ADMIN_PASSWORD` in particular — never launch
  with the example values.
- **HTTPS only in production.** The session cookie is marked `secure` automatically when
  `NODE_ENV=production`, which requires your site to be served over HTTPS. Render, Railway, and
  most modern hosts provide this for you automatically.
- **This is not a payment processor.** The "Give" page records a *pledge* (name, email, amount,
  message) for your team to follow up on — it does not move money. To accept real online
  payments, integrate a payment gateway that supports South Africa, such as PayFast, Yoco, or
  Paystack, and add that on the backend (a good next step, not included here since it needs
  your merchant account credentials).
- **Back up the database file.** `backend/data/church.db` is the entire database. Back it up
  regularly once real members and pledges are in it.

## Deploying (Render, Railway, or a VPS)

You're deploying two things: the **backend** (a Node.js web service) and the **frontend**
(static files). A few ways to do this:

1. **Simplest: serve the frontend from the backend.** Uncomment the
   `app.use(express.static(...))` line near the bottom of `backend/server.js`, deploy only the
   backend, and it will serve both the site and the API from one URL — no CORS config needed.
2. **Separately:** deploy `backend/` as a Node web service, and `frontend/` as a static site
   (Render "Static Site", Railway static deploy, Netlify, Cloudflare Pages, or a VPS with
   nginx). Set `CORS_ORIGIN` on the backend to the exact URL the frontend is served from, and
   set `window.API_BASE` in the frontend to the backend's URL (see step 2 above).

**Important — persistent storage for SQLite:** SQLite stores everything in one file
(`backend/data/church.db`). Most PaaS platforms (Render, Railway, Heroku-style) use an
**ephemeral filesystem** by default — meaning that file is wiped on every redeploy. Before you
have real data you care about, do one of:

- Attach a **persistent disk/volume** to your service (Render: "Disks"; Railway: "Volumes") and
  point `DATABASE_FILE` in `.env` at a path inside that mounted volume.
- Or run the backend on a **VPS** (a plain Linux server) where the filesystem persists.
- Or, for larger deployments, swap SQLite for a managed **Postgres** database — a bigger change
  (different queries in `src/db/` and `src/routes/`), worth doing once you outgrow SQLite.

Either way, set your real environment variables (`SESSION_SECRET`, `ADMIN_EMAIL`,
`ADMIN_PASSWORD`, `CORS_ORIGIN`, `DATABASE_FILE`) in your hosting provider's dashboard — do not
upload your `.env` file itself.

## Project structure

```
frontend/
  index.html, about.html, sermons.html, events.html, give.html
  login.html, register.html, account.html, admin.html
  css/styles.css        — shared design system
  js/api.js              — fetch wrapper for the backend
  js/components.js       — shared header/footer, auth-aware nav
  js/main.js              — small shared page helpers
  images/                — your photos (compressed for web) + logo

backend/
  server.js               — Express app entry point
  src/db/index.js          — SQLite connection + schema
  src/db/seed.js           — creates the admin account + sample content
  src/middleware/auth.js   — requireAuth / requireRole('admin')
  src/routes/auth.js       — register, login, logout, /me
  src/routes/sermons.js    — public GET, admin-only POST/PUT/DELETE
  src/routes/events.js     — public GET, admin-only POST/PUT/DELETE
  src/routes/pledges.js    — public submit, member's-own-history, admin list
  src/routes/users.js      — admin-only member list
  .env.example             — copy to .env and fill in
```
